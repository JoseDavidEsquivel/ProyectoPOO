import csv  # Librería para abrir, leer y escribir archivos CSV


class Despensa:  # Clase Despensa
    def __init__(self): # Constructor de la clase
        pass # Inicializa el objeto

    def listarDespensa(self, fecha: str) -> bool: # Metodo para listarDespensa()
        # TODO programar el método listarDespensa()
        # mostrar los registros por la fecha indicada
        return False # Regresa False si ocurrio un error en el metodo # Regresa False si ocurrio un error en el metodo

    def insertarDespensa(self) -> bool: # Metodo para insertarDespesa()
        # TODO programar el método insertarDespensa()
        return False # Regresa False si ocurrio un error en el metodo

    def buscarDespensa(self,id:int) -> None: # Metodo para buscarDespesa()
        # TODO programar el método buscarDespensa()
        # buscar despensa por id
        return False # Regresa False si ocurrio un error en el metodo

    def borrarDespensa(self,id:int) -> None: # Metodo para borrarDespensa()
        # TODO programar el método borrarDespensa()
        return False # Regresa False si ocurrio un error en el metodo

    def actualizarDespensa(self) -> None: # Metodo para actualizarDespensa()
        # TODO programar el método actualizarDespensa()
        return False # Regresa False si ocurrio un error en el metodo

    def valorMinimoProducto(self,sku:str) -> None: # Metodo para mostrar el valor minimo de un producto
        # TODO programar el método valorMinimoProducto()
        return False # Regresa False si ocurrio un error en el metodo

    def valorMaximoProducto(self,sku:str) -> None: # Metodo para mostrar el valor minimo de un producto
        # TODO programar el método valorMinimoProducto()
        return False # Regresa False si ocurrio un error en el metodo
